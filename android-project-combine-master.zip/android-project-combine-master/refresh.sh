#!/bin/bash
#@author: jacks.gong

bash clean.sh
python .combine/combine.py
