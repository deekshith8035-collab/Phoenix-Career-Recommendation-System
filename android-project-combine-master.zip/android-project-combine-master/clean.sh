rm -rf combine-settings.gradle
rm -rf combine
rm -rf conf
